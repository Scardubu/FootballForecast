# Football Analytics Dashboard

## Overview

A full-stack football analytics application that provides real-time match insights, AI-powered predictions, and betting analysis. The system combines a React frontend with shadcn/ui components and an Express.js backend, using PostgreSQL with Drizzle ORM for data persistence. The application focuses on providing comprehensive football statistics, team comparisons, league standings, and intelligent betting recommendations through machine learning algorithms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with TypeScript**: Modern component-based UI using functional components and hooks
- **shadcn/ui Design System**: Comprehensive UI component library with Radix UI primitives for accessibility
- **TanStack Query**: Server state management for data fetching, caching, and synchronization
- **Wouter**: Lightweight client-side routing solution
- **Tailwind CSS**: Utility-first styling with custom CSS variables for theming
- **Vite**: Fast development server and build tool with hot module replacement

### Backend Architecture
- **Express.js**: RESTful API server with middleware for logging and error handling
- **TypeScript**: Type-safe server-side development
- **Drizzle ORM**: Type-safe database operations with PostgreSQL
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **Middleware Stack**: Request logging, JSON parsing, and error handling

### Database Design
- **PostgreSQL**: Primary database with UUID-based primary keys
- **Schema Structure**:
  - Leagues: Competition management with country and code identification
  - Teams: Team information with league relationships and statistics
  - Matches: Game scheduling with odds, scores, and status tracking
  - Predictions: AI-generated betting insights with confidence levels
  - Team Stats: Performance metrics and form tracking
  - Head-to-Head: Historical matchup data
  - Users: User management system

### API Architecture
- **RESTful Endpoints**: Standard HTTP methods for resource management
- **Nested Resources**: League-specific team queries and match filtering
- **Error Handling**: Centralized error management with appropriate HTTP status codes
- **Response Formatting**: Consistent JSON response structure

### Component Architecture
- **Dashboard Layout**: Sidebar navigation with main content area
- **Modular Components**: Reusable UI components for statistics, charts, and data display
- **Real-time Updates**: Query-based data fetching with automatic refresh capabilities
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

### State Management
- **Server State**: TanStack Query for API data caching and synchronization
- **Local State**: React hooks for component-level state management
- **Form State**: React Hook Form integration with Zod validation
- **UI State**: Component state for modals, dropdowns, and interactive elements

## External Dependencies

### Core Framework Dependencies
- **React**: UI library with TypeScript support
- **Express.js**: Node.js web framework
- **Vite**: Build tool and development server

### Database & ORM
- **PostgreSQL**: Relational database (via Neon serverless)
- **Drizzle ORM**: TypeScript ORM with schema management
- **Drizzle Kit**: Database migration and schema management tools

### UI & Styling
- **Radix UI**: Headless component primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **class-variance-authority**: Component variant management

### Data Management
- **TanStack React Query**: Server state management
- **React Hook Form**: Form state management
- **Zod**: Schema validation and type inference

### Development Tools
- **TypeScript**: Type checking and development experience
- **ESBuild**: Fast JavaScript bundler for production
- **PostCSS**: CSS processing with Autoprefixer

### Third-Party Services
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit Integration**: Development environment with runtime error handling
- **Font Services**: Google Fonts for typography (Inter, DM Sans, Fira Code, Geist Mono)

### Session & Security
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **Express Session**: Session middleware for user authentication