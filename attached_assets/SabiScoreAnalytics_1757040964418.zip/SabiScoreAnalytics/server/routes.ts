import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all leagues
  app.get("/api/leagues", async (req, res) => {
    try {
      const leagues = await storage.getLeagues();
      res.json(leagues);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leagues" });
    }
  });

  // Get teams by league
  app.get("/api/leagues/:leagueId/teams", async (req, res) => {
    try {
      const { leagueId } = req.params;
      const teams = await storage.getTeamsByLeague(leagueId);
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  // Get all teams
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  // Get team by id
  app.get("/api/teams/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  // Get team stats
  app.get("/api/teams/:id/stats", async (req, res) => {
    try {
      const { id } = req.params;
      const stats = await storage.getTeamStats(id);
      if (!stats) {
        return res.status(404).json({ message: "Team stats not found" });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch team stats" });
    }
  });

  // Get upcoming matches
  app.get("/api/matches/upcoming", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const matches = await storage.getUpcomingMatches(limit);
      
      // Enrich matches with team and league data
      const enrichedMatches = await Promise.all(
        matches.map(async (match) => {
          const [homeTeam, awayTeam, league] = await Promise.all([
            storage.getTeam(match.homeTeamId),
            storage.getTeam(match.awayTeamId),
            storage.getLeague(match.leagueId)
          ]);
          
          return {
            ...match,
            homeTeam,
            awayTeam,
            league
          };
        })
      );
      
      res.json(enrichedMatches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  // Get matches by league
  app.get("/api/leagues/:leagueId/matches", async (req, res) => {
    try {
      const { leagueId } = req.params;
      const matches = await storage.getMatchesByLeague(leagueId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  // Get match by id
  app.get("/api/matches/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const match = await storage.getMatch(id);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }

      // Enrich with team data
      const [homeTeam, awayTeam, league] = await Promise.all([
        storage.getTeam(match.homeTeamId),
        storage.getTeam(match.awayTeamId),
        storage.getLeague(match.leagueId)
      ]);

      res.json({
        ...match,
        homeTeam,
        awayTeam,
        league
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch match" });
    }
  });

  // Get predictions for a match
  app.get("/api/matches/:id/predictions", async (req, res) => {
    try {
      const { id } = req.params;
      const predictions = await storage.getPredictionsByMatch(id);
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch predictions" });
    }
  });

  // Get all predictions
  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getPredictions();
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch predictions" });
    }
  });

  // Get head-to-head data
  app.get("/api/teams/:team1Id/head-to-head/:team2Id", async (req, res) => {
    try {
      const { team1Id, team2Id } = req.params;
      const h2h = await storage.getHeadToHead(team1Id, team2Id);
      if (!h2h) {
        return res.status(404).json({ message: "Head-to-head data not found" });
      }
      res.json(h2h);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch head-to-head data" });
    }
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const [matches, predictions] = await Promise.all([
        storage.getUpcomingMatches(),
        storage.getPredictions()
      ]);

      const today = new Date();
      const todayMatches = matches.filter(match => {
        const matchDate = new Date(match.kickoffTime);
        return matchDate.toDateString() === today.toDateString();
      });

      // Calculate prediction accuracy (mock calculation)
      const accuracy = 78.4;
      const activeLeagues = 6;
      const totalPredictions = predictions.length;

      res.json({
        todayMatches: todayMatches.length,
        predictionAccuracy: accuracy,
        activeLeagues,
        totalPredictions
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
