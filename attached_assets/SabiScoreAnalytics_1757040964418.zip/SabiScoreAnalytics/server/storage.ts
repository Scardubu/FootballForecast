import { 
  type League, type Team, type Match, type Prediction, type TeamStats, type HeadToHead, type User,
  type InsertLeague, type InsertTeam, type InsertMatch, type InsertPrediction, type InsertTeamStats, type InsertHeadToHead, type InsertUser
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // League methods
  getLeagues(): Promise<League[]>;
  getLeague(id: string): Promise<League | undefined>;
  createLeague(league: InsertLeague): Promise<League>;

  // Team methods
  getTeams(): Promise<Team[]>;
  getTeamsByLeague(leagueId: string): Promise<Team[]>;
  getTeam(id: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: string, updates: Partial<Team>): Promise<Team | undefined>;

  // Match methods
  getMatches(): Promise<Match[]>;
  getUpcomingMatches(limit?: number): Promise<Match[]>;
  getMatchesByLeague(leagueId: string): Promise<Match[]>;
  getMatch(id: string): Promise<Match | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;

  // Prediction methods
  getPredictions(): Promise<Prediction[]>;
  getPredictionsByMatch(matchId: string): Promise<Prediction[]>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;

  // Team stats methods
  getTeamStats(teamId: string): Promise<TeamStats | undefined>;
  createTeamStats(stats: InsertTeamStats): Promise<TeamStats>;
  updateTeamStats(teamId: string, updates: Partial<TeamStats>): Promise<TeamStats | undefined>;

  // Head to head methods
  getHeadToHead(team1Id: string, team2Id: string): Promise<HeadToHead | undefined>;
  createHeadToHead(h2h: InsertHeadToHead): Promise<HeadToHead>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private leagues: Map<string, League>;
  private teams: Map<string, Team>;
  private matches: Map<string, Match>;
  private predictions: Map<string, Prediction>;
  private teamStats: Map<string, TeamStats>;
  private headToHead: Map<string, HeadToHead>;

  constructor() {
    this.users = new Map();
    this.leagues = new Map();
    this.teams = new Map();
    this.matches = new Map();
    this.predictions = new Map();
    this.teamStats = new Map();
    this.headToHead = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create leagues - Top 6 European leagues
    const leagues = [
      { id: "pl-1", name: "Premier League", country: "England", code: "PL", active: true },
      { id: "ll-1", name: "La Liga", country: "Spain", code: "LL", active: true },
      { id: "bl-1", name: "Bundesliga", country: "Germany", code: "BL", active: true },
      { id: "sa-1", name: "Serie A", country: "Italy", code: "SA", active: true },
      { id: "l1-1", name: "Ligue 1", country: "France", code: "L1", active: true },
      { id: "cl-1", name: "Champions League", country: "Europe", code: "CL", active: true }
    ];
    
    leagues.forEach(league => this.leagues.set(league.id, league));

    // Create teams with current 2024-25 season standings
    const teams = [
      // Premier League
      { id: "team-1", name: "Liverpool", shortName: "LIV", leagueId: "pl-1", position: 1, played: 20, won: 14, drawn: 4, lost: 2, goalsFor: 47, goalsAgainst: 19, points: 46, form: "WWWDW" },
      { id: "team-2", name: "Arsenal", shortName: "ARS", leagueId: "pl-1", position: 2, played: 21, won: 12, drawn: 7, lost: 2, goalsFor: 39, goalsAgainst: 18, points: 43, form: "DWWLD" },
      { id: "team-3", name: "Chelsea", shortName: "CHE", leagueId: "pl-1", position: 3, played: 21, won: 12, drawn: 5, lost: 4, goalsFor: 43, goalsAgainst: 26, points: 41, form: "WLWWW" },
      { id: "team-4", name: "Nottingham Forest", shortName: "NFO", leagueId: "pl-1", position: 4, played: 21, won: 12, drawn: 4, lost: 5, goalsFor: 29, goalsAgainst: 19, points: 40, form: "WWLDW" },
      { id: "team-5", name: "Newcastle United", shortName: "NEW", leagueId: "pl-1", position: 5, played: 21, won: 11, drawn: 5, lost: 5, goalsFor: 35, goalsAgainst: 21, points: 38, form: "DWWWD" },
      { id: "team-6", name: "Manchester City", shortName: "MCI", leagueId: "pl-1", position: 6, played: 21, won: 11, drawn: 4, lost: 6, goalsFor: 36, goalsAgainst: 27, points: 37, form: "LWDWW" },
      
      // La Liga
      { id: "team-7", name: "Real Madrid", shortName: "RMA", leagueId: "ll-1", position: 1, played: 19, won: 13, drawn: 3, lost: 3, goalsFor: 41, goalsAgainst: 18, points: 42, form: "WWDWW" },
      { id: "team-8", name: "Barcelona", shortName: "BAR", leagueId: "ll-1", position: 2, played: 20, won: 12, drawn: 2, lost: 6, goalsFor: 51, goalsAgainst: 22, points: 38, form: "WLWWL" },
      { id: "team-9", name: "Atletico Madrid", shortName: "ATM", leagueId: "ll-1", position: 3, played: 19, won: 11, drawn: 5, lost: 3, goalsFor: 31, goalsAgainst: 12, points: 38, form: "WDDWW" },
      
      // Bundesliga
      { id: "team-10", name: "Bayern Munich", shortName: "BAY", leagueId: "bl-1", position: 1, played: 16, won: 12, drawn: 3, lost: 1, goalsFor: 47, goalsAgainst: 13, points: 39, form: "WWWWW" },
      { id: "team-11", name: "Bayer Leverkusen", shortName: "B04", leagueId: "bl-1", position: 2, played: 16, won: 9, drawn: 5, lost: 2, goalsFor: 37, goalsAgainst: 21, points: 32, form: "WDWDW" },
      { id: "team-12", name: "Eintracht Frankfurt", shortName: "SGE", leagueId: "bl-1", position: 3, played: 16, won: 9, drawn: 3, lost: 4, goalsFor: 35, goalsAgainst: 23, points: 30, form: "LWWWL" },
      
      // Serie A
      { id: "team-13", name: "Napoli", shortName: "NAP", leagueId: "sa-1", position: 1, played: 20, won: 14, drawn: 2, lost: 4, goalsFor: 32, goalsAgainst: 12, points: 44, form: "WWWLW" },
      { id: "team-14", name: "Atalanta", shortName: "ATA", leagueId: "sa-1", position: 2, played: 19, won: 13, drawn: 1, lost: 5, goalsFor: 41, goalsAgainst: 19, points: 40, form: "WLWWW" },
      { id: "team-15", name: "Inter Milan", shortName: "INT", leagueId: "sa-1", position: 3, played: 19, won: 11, drawn: 4, lost: 4, goalsFor: 40, goalsAgainst: 17, points: 37, form: "DWWWL" },
      
      // Ligue 1
      { id: "team-16", name: "Paris Saint-Germain", shortName: "PSG", leagueId: "l1-1", position: 1, played: 18, won: 14, drawn: 2, lost: 2, goalsFor: 44, goalsAgainst: 14, points: 44, form: "WWWWW" },
      { id: "team-17", name: "Marseille", shortName: "MAR", leagueId: "l1-1", position: 2, played: 18, won: 11, drawn: 3, lost: 4, goalsFor: 32, goalsAgainst: 18, points: 36, form: "WLWDW" },
      { id: "team-18", name: "Monaco", shortName: "MON", leagueId: "l1-1", position: 3, played: 18, won: 10, drawn: 4, lost: 4, goalsFor: 26, goalsAgainst: 16, points: 34, form: "DDWWL" }
    ];

    teams.forEach(team => this.teams.set(team.id, team));

    // Create upcoming matches across multiple leagues
    const now = new Date();
    const matches = [
      // Premier League matches
      {
        id: "match-1",
        homeTeamId: "team-3", // Chelsea
        awayTeamId: "team-2", // Arsenal  
        leagueId: "pl-1",
        kickoffTime: new Date(now.getTime() + 3 * 60 * 60 * 1000), // 3 hours from now
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 2.45, draw: 3.20, away: 2.90 }
      },
      {
        id: "match-2",
        homeTeamId: "team-1", // Liverpool
        awayTeamId: "team-6", // Man City
        leagueId: "pl-1",
        kickoffTime: new Date(now.getTime() + 28 * 60 * 60 * 1000), // tomorrow evening
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 2.10, draw: 3.60, away: 3.30 }
      },
      {
        id: "match-3",
        homeTeamId: "team-4", // Nottingham Forest
        awayTeamId: "team-5", // Newcastle
        leagueId: "pl-1",
        kickoffTime: new Date(now.getTime() + 52 * 60 * 60 * 1000), // 2 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 2.75, draw: 3.10, away: 2.65 }
      },
      // La Liga matches
      {
        id: "match-4",
        homeTeamId: "team-8", // Barcelona
        awayTeamId: "team-7", // Real Madrid
        leagueId: "ll-1",
        kickoffTime: new Date(now.getTime() + 76 * 60 * 60 * 1000), // 3 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 2.80, draw: 3.40, away: 2.50 }
      },
      {
        id: "match-5",
        homeTeamId: "team-9", // Atletico Madrid
        awayTeamId: "team-8", // Barcelona
        leagueId: "ll-1",
        kickoffTime: new Date(now.getTime() + 100 * 60 * 60 * 1000), // 4 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 3.10, draw: 3.20, away: 2.30 }
      },
      // Bundesliga matches
      {
        id: "match-6",
        homeTeamId: "team-11", // Bayer Leverkusen
        awayTeamId: "team-10", // Bayern Munich
        leagueId: "bl-1",
        kickoffTime: new Date(now.getTime() + 124 * 60 * 60 * 1000), // 5 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 3.50, draw: 3.80, away: 2.00 }
      },
      // Serie A matches
      {
        id: "match-7",
        homeTeamId: "team-15", // Inter Milan
        awayTeamId: "team-13", // Napoli
        leagueId: "sa-1",
        kickoffTime: new Date(now.getTime() + 148 * 60 * 60 * 1000), // 6 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 2.20, draw: 3.30, away: 3.25 }
      },
      // Ligue 1 matches
      {
        id: "match-8",
        homeTeamId: "team-17", // Marseille
        awayTeamId: "team-16", // PSG
        leagueId: "l1-1",
        kickoffTime: new Date(now.getTime() + 172 * 60 * 60 * 1000), // 7 days
        status: "scheduled" as const,
        homeScore: null,
        awayScore: null,
        odds: { home: 4.20, draw: 3.60, away: 1.85 }
      }
    ];

    matches.forEach(match => this.matches.set(match.id, match));

    // Create diverse predictions across matches and bet types
    const predictions = [
      {
        id: "pred-1",
        matchId: "match-1", // Chelsea vs Arsenal
        predictionType: "over_under",
        prediction: "over_2.5",
        confidence: "82.30",
        odds: "1.90",
        expectedValue: "11.40",
        reasoning: "Chelsea's attack has been prolific at home (2.1 goals/game) and Arsenal averages 1.9 goals per away match. Both teams concede regularly.",
        createdAt: new Date()
      },
      {
        id: "pred-2",
        matchId: "match-1", // Chelsea vs Arsenal
        predictionType: "btts",
        prediction: "btts_yes",
        confidence: "76.50",
        odds: "1.72",
        expectedValue: "9.20",
        reasoning: "Arsenal scored in 8 of their last 10 away games, while Chelsea conceded in 6 of last 8 home matches.",
        createdAt: new Date()
      },
      {
        id: "pred-3",
        matchId: "match-2", // Liverpool vs Man City
        predictionType: "match_result",
        prediction: "home",
        confidence: "68.70",
        odds: "2.10",
        expectedValue: "16.30",
        reasoning: "Liverpool's unbeaten home record and City's recent away struggles make this excellent value for a home win.",
        createdAt: new Date()
      },
      {
        id: "pred-4",
        matchId: "match-4", // Barcelona vs Real Madrid
        predictionType: "over_under",
        prediction: "over_2.5",
        confidence: "89.10",
        odds: "1.75",
        expectedValue: "18.50",
        reasoning: "El Clasico historically averages 3.2 goals. Barcelona's attack vs Real's defensive vulnerabilities suggest high-scoring affair.",
        createdAt: new Date()
      },
      {
        id: "pred-5",
        matchId: "match-6", // Bayer Leverkusen vs Bayern Munich
        predictionType: "match_result",
        prediction: "away",
        confidence: "71.20",
        odds: "2.00",
        expectedValue: "13.80",
        reasoning: "Bayern's dominant form (12W-3D-1L) and Leverkusen's inconsistent home record favor the visitors.",
        createdAt: new Date()
      },
      {
        id: "pred-6",
        matchId: "match-7", // Inter Milan vs Napoli
        predictionType: "under_over",
        prediction: "under_2.5",
        confidence: "79.40",
        odds: "2.05",
        expectedValue: "14.70",
        reasoning: "Both teams have strong defensive records. Napoli allows only 0.6 goals/game, Inter 0.9 goals/game.",
        createdAt: new Date()
      },
      {
        id: "pred-7",
        matchId: "match-8", // Marseille vs PSG
        predictionType: "handicap",
        prediction: "psg_-1",
        confidence: "73.60",
        odds: "1.95",
        expectedValue: "12.10",
        reasoning: "PSG's superior quality and Marseille's home defensive issues suggest comfortable away victory.",
        createdAt: new Date()
      },
      {
        id: "pred-8",
        matchId: "match-3", // Nottingham Forest vs Newcastle
        predictionType: "btts",
        prediction: "btts_no",
        confidence: "65.80",
        odds: "2.20",
        expectedValue: "10.50",
        reasoning: "Forest's strong home defense (0.9 goals conceded/game at home) against Newcastle's inconsistent away attack.",
        createdAt: new Date()
      }
    ];

    predictions.forEach(pred => this.predictions.set(pred.id, pred));

    // Create comprehensive team stats based on current season performance
    const statsData = [
      // Premier League
      { teamId: "team-1", attackRating: "8.7", defenseRating: "8.5", goalsPerMatch: "2.4", shotsOnTarget: "5.8", cleanSheetPercentage: "50.00", possessionPercentage: "64.00" }, // Liverpool
      { teamId: "team-2", attackRating: "7.8", defenseRating: "8.9", goalsPerMatch: "1.9", shotsOnTarget: "4.6", cleanSheetPercentage: "57.00", possessionPercentage: "67.00" }, // Arsenal
      { teamId: "team-3", attackRating: "8.1", defenseRating: "7.2", goalsPerMatch: "2.0", shotsOnTarget: "5.2", cleanSheetPercentage: "38.00", possessionPercentage: "61.00" }, // Chelsea
      { teamId: "team-4", attackRating: "6.8", defenseRating: "8.3", goalsPerMatch: "1.4", shotsOnTarget: "3.9", cleanSheetPercentage: "48.00", possessionPercentage: "42.00" }, // Nottingham Forest
      { teamId: "team-5", attackRating: "7.4", defenseRating: "7.8", goalsPerMatch: "1.7", shotsOnTarget: "4.3", cleanSheetPercentage: "43.00", possessionPercentage: "52.00" }, // Newcastle
      { teamId: "team-6", attackRating: "8.0", defenseRating: "6.9", goalsPerMatch: "1.7", shotsOnTarget: "4.8", cleanSheetPercentage: "33.00", possessionPercentage: "68.00" }, // Man City
      
      // La Liga
      { teamId: "team-7", attackRating: "8.9", defenseRating: "8.4", goalsPerMatch: "2.2", shotsOnTarget: "5.5", cleanSheetPercentage: "58.00", possessionPercentage: "65.00" }, // Real Madrid
      { teamId: "team-8", attackRating: "9.2", defenseRating: "7.8", goalsPerMatch: "2.6", shotsOnTarget: "6.2", cleanSheetPercentage: "45.00", possessionPercentage: "72.00" }, // Barcelona
      { teamId: "team-9", attackRating: "7.1", defenseRating: "9.1", goalsPerMatch: "1.6", shotsOnTarget: "4.1", cleanSheetPercentage: "68.00", possessionPercentage: "48.00" }, // Atletico Madrid
      
      // Bundesliga
      { teamId: "team-10", attackRating: "9.0", defenseRating: "8.7", goalsPerMatch: "2.9", shotsOnTarget: "6.8", cleanSheetPercentage: "56.00", possessionPercentage: "67.00" }, // Bayern Munich
      { teamId: "team-11", attackRating: "8.3", defenseRating: "7.5", goalsPerMatch: "2.3", shotsOnTarget: "5.4", cleanSheetPercentage: "44.00", possessionPercentage: "61.00" }, // Bayer Leverkusen
      { teamId: "team-12", attackRating: "8.0", defenseRating: "7.2", goalsPerMatch: "2.2", shotsOnTarget: "5.1", cleanSheetPercentage: "38.00", possessionPercentage: "55.00" }, // Eintracht Frankfurt
      
      // Serie A  
      { teamId: "team-13", attackRating: "7.6", defenseRating: "9.3", goalsPerMatch: "1.6", shotsOnTarget: "4.2", cleanSheetPercentage: "70.00", possessionPercentage: "53.00" }, // Napoli
      { teamId: "team-14", attackRating: "8.8", defenseRating: "7.9", goalsPerMatch: "2.2", shotsOnTarget: "5.7", cleanSheetPercentage: "47.00", possessionPercentage: "58.00" }, // Atalanta
      { teamId: "team-15", attackRating: "8.2", defenseRating: "8.6", goalsPerMatch: "2.1", shotsOnTarget: "5.3", cleanSheetPercentage: "53.00", possessionPercentage: "62.00" }, // Inter Milan
      
      // Ligue 1
      { teamId: "team-16", attackRating: "8.9", defenseRating: "8.8", goalsPerMatch: "2.4", shotsOnTarget: "6.1", cleanSheetPercentage: "61.00", possessionPercentage: "64.00" }, // PSG
      { teamId: "team-17", attackRating: "7.7", defenseRating: "7.4", goalsPerMatch: "1.8", shotsOnTarget: "4.7", cleanSheetPercentage: "39.00", possessionPercentage: "56.00" }, // Marseille
      { teamId: "team-18", attackRating: "6.9", defenseRating: "8.2", goalsPerMatch: "1.4", shotsOnTarget: "3.8", cleanSheetPercentage: "50.00", possessionPercentage: "49.00" }  // Monaco
    ];

    statsData.forEach(stats => {
      const teamStats: TeamStats = {
        id: randomUUID(),
        teamId: stats.teamId,
        attackRating: stats.attackRating,
        defenseRating: stats.defenseRating,
        goalsPerMatch: stats.goalsPerMatch,
        shotsOnTarget: stats.shotsOnTarget,
        cleanSheetPercentage: stats.cleanSheetPercentage,
        possessionPercentage: stats.possessionPercentage,
        lastUpdated: new Date()
      };
      this.teamStats.set(stats.teamId, teamStats);
    });

    // Create realistic head-to-head data for major fixtures
    const h2hData = [
      { team1Id: "team-3", team2Id: "team-2", team1Wins: 5, team2Wins: 7, draws: 3, totalMatches: 15 }, // Chelsea vs Arsenal
      { team1Id: "team-2", team2Id: "team-3", team1Wins: 7, team2Wins: 5, draws: 3, totalMatches: 15 }, // Arsenal vs Chelsea (reverse)
      { team1Id: "team-1", team2Id: "team-6", team1Wins: 8, team2Wins: 4, draws: 3, totalMatches: 15 }, // Liverpool vs Man City
      { team1Id: "team-6", team2Id: "team-1", team1Wins: 4, team2Wins: 8, draws: 3, totalMatches: 15 }, // Man City vs Liverpool (reverse)
      { team1Id: "team-8", team2Id: "team-7", team1Wins: 6, team2Wins: 8, draws: 6, totalMatches: 20 }, // Barcelona vs Real Madrid
      { team1Id: "team-7", team2Id: "team-8", team1Wins: 8, team2Wins: 6, draws: 6, totalMatches: 20 }, // Real Madrid vs Barcelona (reverse)
      { team1Id: "team-11", team2Id: "team-10", team1Wins: 2, team2Wins: 12, draws: 1, totalMatches: 15 }, // Leverkusen vs Bayern
      { team1Id: "team-10", team2Id: "team-11", team1Wins: 12, team2Wins: 2, draws: 1, totalMatches: 15 }, // Bayern vs Leverkusen (reverse)
      { team1Id: "team-15", team2Id: "team-13", team1Wins: 7, team2Wins: 5, draws: 3, totalMatches: 15 }, // Inter vs Napoli
      { team1Id: "team-13", team2Id: "team-15", team1Wins: 5, team2Wins: 7, draws: 3, totalMatches: 15 }, // Napoli vs Inter (reverse)
      { team1Id: "team-17", team2Id: "team-16", team1Wins: 3, team2Wins: 9, draws: 3, totalMatches: 15 }, // Marseille vs PSG
      { team1Id: "team-16", team2Id: "team-17", team1Wins: 9, team2Wins: 3, draws: 3, totalMatches: 15 }  // PSG vs Marseille (reverse)
    ];

    h2hData.forEach(data => {
      const h2h: HeadToHead = {
        id: randomUUID(),
        team1Id: data.team1Id,
        team2Id: data.team2Id,
        team1Wins: data.team1Wins,
        team2Wins: data.team2Wins,
        draws: data.draws,
        totalMatches: data.totalMatches,
        lastUpdated: new Date()
      };
      this.headToHead.set(`${data.team1Id}-${data.team2Id}`, h2h);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // League methods
  async getLeagues(): Promise<League[]> {
    return Array.from(this.leagues.values());
  }

  async getLeague(id: string): Promise<League | undefined> {
    return this.leagues.get(id);
  }

  async createLeague(insertLeague: InsertLeague): Promise<League> {
    const id = randomUUID();
    const league: League = { 
      ...insertLeague, 
      id,
      active: insertLeague.active ?? true 
    };
    this.leagues.set(id, league);
    return league;
  }

  // Team methods
  async getTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }

  async getTeamsByLeague(leagueId: string): Promise<Team[]> {
    return Array.from(this.teams.values())
      .filter(team => team.leagueId === leagueId)
      .sort((a, b) => (a.position || 0) - (b.position || 0));
  }

  async getTeam(id: string): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = randomUUID();
    const team: Team = { 
      ...insertTeam, 
      id,
      position: insertTeam.position ?? null,
      played: insertTeam.played ?? 0,
      won: insertTeam.won ?? 0,
      drawn: insertTeam.drawn ?? 0,
      lost: insertTeam.lost ?? 0,
      goalsFor: insertTeam.goalsFor ?? 0,
      goalsAgainst: insertTeam.goalsAgainst ?? 0,
      points: insertTeam.points ?? 0,
      form: insertTeam.form ?? null
    };
    this.teams.set(id, team);
    return team;
  }

  async updateTeam(id: string, updates: Partial<Team>): Promise<Team | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const updatedTeam = { ...team, ...updates };
    this.teams.set(id, updatedTeam);
    return updatedTeam;
  }

  // Match methods
  async getMatches(): Promise<Match[]> {
    return Array.from(this.matches.values());
  }

  async getUpcomingMatches(limit = 10): Promise<Match[]> {
    const now = new Date();
    return Array.from(this.matches.values())
      .filter(match => match.status === "scheduled" && match.kickoffTime > now)
      .sort((a, b) => a.kickoffTime.getTime() - b.kickoffTime.getTime())
      .slice(0, limit);
  }

  async getMatchesByLeague(leagueId: string): Promise<Match[]> {
    return Array.from(this.matches.values())
      .filter(match => match.leagueId === leagueId);
  }

  async getMatch(id: string): Promise<Match | undefined> {
    return this.matches.get(id);
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = randomUUID();
    const match: Match = { 
      ...insertMatch, 
      id,
      status: insertMatch.status ?? "scheduled",
      homeScore: insertMatch.homeScore ?? null,
      awayScore: insertMatch.awayScore ?? null,
      odds: insertMatch.odds ?? null
    };
    this.matches.set(id, match);
    return match;
  }

  // Prediction methods
  async getPredictions(): Promise<Prediction[]> {
    return Array.from(this.predictions.values());
  }

  async getPredictionsByMatch(matchId: string): Promise<Prediction[]> {
    return Array.from(this.predictions.values())
      .filter(pred => pred.matchId === matchId);
  }

  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const id = randomUUID();
    const prediction: Prediction = { 
      ...insertPrediction, 
      id,
      odds: insertPrediction.odds ?? null,
      expectedValue: insertPrediction.expectedValue ?? null,
      reasoning: insertPrediction.reasoning ?? null,
      createdAt: insertPrediction.createdAt ?? new Date()
    };
    this.predictions.set(id, prediction);
    return prediction;
  }

  // Team stats methods
  async getTeamStats(teamId: string): Promise<TeamStats | undefined> {
    return this.teamStats.get(teamId);
  }

  async createTeamStats(insertStats: InsertTeamStats): Promise<TeamStats> {
    const id = randomUUID();
    const stats: TeamStats = { 
      ...insertStats, 
      id,
      attackRating: insertStats.attackRating ?? null,
      defenseRating: insertStats.defenseRating ?? null,
      goalsPerMatch: insertStats.goalsPerMatch ?? null,
      shotsOnTarget: insertStats.shotsOnTarget ?? null,
      cleanSheetPercentage: insertStats.cleanSheetPercentage ?? null,
      possessionPercentage: insertStats.possessionPercentage ?? null,
      lastUpdated: insertStats.lastUpdated ?? new Date()
    };
    this.teamStats.set(insertStats.teamId, stats);
    return stats;
  }

  async updateTeamStats(teamId: string, updates: Partial<TeamStats>): Promise<TeamStats | undefined> {
    const stats = this.teamStats.get(teamId);
    if (!stats) return undefined;
    
    const updatedStats = { ...stats, ...updates };
    this.teamStats.set(teamId, updatedStats);
    return updatedStats;
  }

  // Head to head methods
  async getHeadToHead(team1Id: string, team2Id: string): Promise<HeadToHead | undefined> {
    return this.headToHead.get(`${team1Id}-${team2Id}`) || this.headToHead.get(`${team2Id}-${team1Id}`);
  }

  async createHeadToHead(insertH2H: InsertHeadToHead): Promise<HeadToHead> {
    const id = randomUUID();
    const h2h: HeadToHead = { 
      ...insertH2H, 
      id,
      team1Wins: insertH2H.team1Wins ?? 0,
      team2Wins: insertH2H.team2Wins ?? 0,
      draws: insertH2H.draws ?? 0,
      totalMatches: insertH2H.totalMatches ?? 0,
      lastUpdated: insertH2H.lastUpdated ?? new Date()
    };
    this.headToHead.set(`${insertH2H.team1Id}-${insertH2H.team2Id}`, h2h);
    return h2h;
  }
}

export const storage = new MemStorage();
