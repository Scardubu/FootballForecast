import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const leagues = pgTable("leagues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: text("country").notNull(),
  code: text("code").notNull().unique(),
  active: boolean("active").default(true),
});

export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  leagueId: varchar("league_id").references(() => leagues.id).notNull(),
  position: integer("position"),
  played: integer("played").default(0),
  won: integer("won").default(0),
  drawn: integer("drawn").default(0),
  lost: integer("lost").default(0),
  goalsFor: integer("goals_for").default(0),
  goalsAgainst: integer("goals_against").default(0),
  points: integer("points").default(0),
  form: text("form"), // Last 5 matches: "WWDLW"
});

export const matches = pgTable("matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  homeTeamId: varchar("home_team_id").references(() => teams.id).notNull(),
  awayTeamId: varchar("away_team_id").references(() => teams.id).notNull(),
  leagueId: varchar("league_id").references(() => leagues.id).notNull(),
  kickoffTime: timestamp("kickoff_time").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, live, finished
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  odds: jsonb("odds"), // { home: 2.1, draw: 3.4, away: 2.8 }
});

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  matchId: varchar("match_id").references(() => matches.id).notNull(),
  predictionType: text("prediction_type").notNull(), // "match_result", "over_under", "btts"
  prediction: text("prediction").notNull(), // "home", "away", "draw", "over_2.5", "btts_yes"
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  odds: decimal("odds", { precision: 5, scale: 2 }),
  expectedValue: decimal("expected_value", { precision: 5, scale: 2 }),
  reasoning: text("reasoning"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const teamStats = pgTable("team_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").references(() => teams.id).notNull(),
  attackRating: decimal("attack_rating", { precision: 3, scale: 1 }),
  defenseRating: decimal("defense_rating", { precision: 3, scale: 1 }),
  goalsPerMatch: decimal("goals_per_match", { precision: 3, scale: 1 }),
  shotsOnTarget: decimal("shots_on_target", { precision: 3, scale: 1 }),
  cleanSheetPercentage: decimal("clean_sheet_percentage", { precision: 5, scale: 2 }),
  possessionPercentage: decimal("possession_percentage", { precision: 5, scale: 2 }),
  lastUpdated: timestamp("last_updated").default(sql`CURRENT_TIMESTAMP`),
});

export const headToHead = pgTable("head_to_head", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  team1Id: varchar("team1_id").references(() => teams.id).notNull(),
  team2Id: varchar("team2_id").references(() => teams.id).notNull(),
  team1Wins: integer("team1_wins").default(0),
  team2Wins: integer("team2_wins").default(0),
  draws: integer("draws").default(0),
  totalMatches: integer("total_matches").default(0),
  lastUpdated: timestamp("last_updated").default(sql`CURRENT_TIMESTAMP`),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Insert schemas
export const insertLeagueSchema = createInsertSchema(leagues).omit({ id: true });
export const insertTeamSchema = createInsertSchema(teams).omit({ id: true });
export const insertMatchSchema = createInsertSchema(matches).omit({ id: true });
export const insertPredictionSchema = createInsertSchema(predictions).omit({ id: true });
export const insertTeamStatsSchema = createInsertSchema(teamStats).omit({ id: true });
export const insertHeadToHeadSchema = createInsertSchema(headToHead).omit({ id: true });
export const insertUserSchema = createInsertSchema(users).omit({ id: true });

// Types
export type League = typeof leagues.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type Match = typeof matches.$inferSelect;
export type Prediction = typeof predictions.$inferSelect;
export type TeamStats = typeof teamStats.$inferSelect;
export type HeadToHead = typeof headToHead.$inferSelect;
export type User = typeof users.$inferSelect;

export type InsertLeague = z.infer<typeof insertLeagueSchema>;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type InsertTeamStats = z.infer<typeof insertTeamStatsSchema>;
export type InsertHeadToHead = z.infer<typeof insertHeadToHeadSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
