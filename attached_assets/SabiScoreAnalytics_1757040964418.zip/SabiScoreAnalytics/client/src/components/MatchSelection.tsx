import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Shield, Info, TrendingUp, Activity } from "lucide-react";
import type { Match, Team, League } from "@shared/schema";

interface EnrichedMatch extends Match {
  homeTeam: Team;
  awayTeam: Team;
  league: League;
}

export default function MatchSelection() {
  const { data: matches = [] } = useQuery<EnrichedMatch[]>({
    queryKey: ["/api/matches/upcoming"],
  });

  const formatMatchTime = (kickoffTime: string | Date) => {
    const date = new Date(kickoffTime);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const matchDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    let dayText = "";
    if (matchDate.getTime() === today.getTime()) {
      dayText = "Today";
    } else if (matchDate.getTime() === tomorrow.getTime()) {
      dayText = "Tomorrow";
    } else {
      dayText = date.toLocaleDateString("en-US", { weekday: "long" });
    }

    const timeText = date.toLocaleTimeString("en-US", { 
      hour: "2-digit", 
      minute: "2-digit",
      hour12: false 
    });

    return { dayText, timeText };
  };

  const getOddsColor = (type: 'home' | 'draw' | 'away') => {
    switch (type) {
      case 'home': return 'bg-success/20 text-success';
      case 'draw': return 'bg-muted text-muted-foreground';
      case 'away': return 'bg-secondary/20 text-secondary';
    }
  };

  const getTeamFlag = (teamName: string) => {
    const flagMap: Record<string, string> = {
      'Liverpool': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Arsenal': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Chelsea': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Manchester City': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Newcastle United': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Nottingham Forest': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
      'Real Madrid': '🇪🇸', 'Barcelona': '🇪🇸', 'Atletico Madrid': '🇪🇸',
      'Bayern Munich': '🇩🇪', 'Bayer Leverkusen': '🇩🇪', 'Eintracht Frankfurt': '🇩🇪',
      'Napoli': '🇮🇹', 'Inter Milan': '🇮🇹', 'Atalanta': '🇮🇹',
      'Paris Saint-Germain': '🇫🇷', 'Marseille': '🇫🇷', 'Monaco': '🇫🇷'
    };
    return flagMap[teamName] || '⚽';
  };

  const getValueTip = (odds: { home: number; draw: number; away: number }) => {
    const homeImplied = (1 / odds.home) * 100;
    const awayImplied = (1 / odds.away) * 100;
    const drawImplied = (1 / odds.draw) * 100;
    const margin = homeImplied + awayImplied + drawImplied - 100;
    return `Bookmaker margin: ${margin.toFixed(1)}% • Home probability: ${homeImplied.toFixed(1)}%`;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CardTitle className="text-lg md:text-xl">Select Match for Analysis</CardTitle>
          <Select defaultValue="all">
            <SelectTrigger className="w-full md:w-48 gap-2" data-testid="select-league-filter">
              <SelectValue placeholder="🌍 All Leagues" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">🌍 All Leagues</SelectItem>
              <SelectItem value="pl-1">🏴󠁧󠁢󠁥󠁮󠁧󠁿 Premier League</SelectItem>
              <SelectItem value="ll-1">🇪🇸 La Liga</SelectItem>
              <SelectItem value="bl-1">🇩🇪 Bundesliga</SelectItem>
              <SelectItem value="sa-1">🇮🇹 Serie A</SelectItem>
              <SelectItem value="l1-1">🇫🇷 Ligue 1</SelectItem>
              <SelectItem value="cl-1">🏆 Champions League</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {matches.map((match) => {
          const { dayText, timeText } = formatMatchTime(match.kickoffTime);
          const odds = match.odds as { home: number; draw: number; away: number } || {};
          
          return (
            <div
              key={match.id}
              className="border border-border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors"
              data-testid={`match-card-${match.id}`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-2 md:gap-4">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="text-center cursor-pointer">
                        <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-primary/10 to-primary/20 rounded-full flex items-center justify-center mb-2 relative border-2 border-primary/20">
                          <span className="text-xl md:text-2xl">{getTeamFlag(match.homeTeam.name)}</span>
                          <div className="absolute -top-1 -right-1 w-5 h-5 md:w-6 md:h-6 bg-success rounded-full flex items-center justify-center">
                            <span className="text-xs font-bold text-success-foreground">H</span>
                          </div>
                        </div>
                        <span className="text-sm font-medium" data-testid={`team-home-${match.homeTeam.shortName}`}>
                          {match.homeTeam.shortName}
                        </span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="font-semibold">{match.homeTeam.name}</p>
                      <p className="text-xs text-muted-foreground">Home team • Recent form: {match.homeTeam.form || 'N/A'}</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  <div className="text-center px-4">
                    <p className="text-sm text-muted-foreground">{dayText}</p>
                    <p className="text-lg font-bold text-foreground" data-testid={`match-time-${match.id}`}>
                      {timeText}
                    </p>
                    <Badge variant="outline" className="text-xs bg-accent/10">
                      {match.league.code}
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">vs</div>
                  </div>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="text-center cursor-pointer">
                        <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-secondary/10 to-secondary/20 rounded-full flex items-center justify-center mb-2 relative border-2 border-secondary/20">
                          <span className="text-xl md:text-2xl">{getTeamFlag(match.awayTeam.name)}</span>
                          <div className="absolute -top-1 -right-1 w-5 h-5 md:w-6 md:h-6 bg-muted rounded-full flex items-center justify-center">
                            <span className="text-xs font-bold text-muted-foreground">A</span>
                          </div>
                        </div>
                        <span className="text-sm font-medium" data-testid={`team-away-${match.awayTeam.shortName}`}>
                          {match.awayTeam.shortName}
                        </span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="font-semibold">{match.awayTeam.name}</p>
                      <p className="text-xs text-muted-foreground">Away team • Recent form: {match.awayTeam.form || 'N/A'}</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <div className="text-right">
                  {odds.home && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex gap-2 text-xs mb-3 cursor-help">
                          <Badge className={getOddsColor('home')}>1: {odds.home}</Badge>
                          <Badge className={getOddsColor('draw')}>X: {odds.draw}</Badge>
                          <Badge className={getOddsColor('away')}>2: {odds.away}</Badge>
                          <Info className="w-3 h-3 text-muted-foreground ml-1" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-xs">{getValueTip(odds)}</p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                  <div className="space-y-2">
                    <Button 
                      size="sm" 
                      className="bg-primary text-primary-foreground w-full"
                      data-testid={`button-analyze-${match.id}`}
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      Analyze Match
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="w-full text-xs"
                    >
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Quick Prediction
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
