import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Volleyball, BarChart3, Calendar, Trophy, Users, TrendingUp, History, Filter } from "lucide-react";
import type { League } from "@shared/schema";

export default function Sidebar() {
  const [selectedLeagues, setSelectedLeagues] = useState<string[]>(["pl-1", "ll-1", "bl-1", "sa-1"]);

  const getLeagueFlag = (country: string) => {
    const countryFlags: Record<string, string> = {
      'England': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
      'Spain': '🇪🇸',
      'Germany': '🇩🇪', 
      'Italy': '🇮🇹',
      'France': '🇫🇷',
      'Europe': '🏆'
    };
    return countryFlags[country] || '⚽';
  };

  const { data: leagues = [] } = useQuery<League[]>({
    queryKey: ["/api/leagues"],
  });

  const handleLeagueToggle = (leagueId: string, checked: boolean) => {
    if (checked) {
      setSelectedLeagues([...selectedLeagues, leagueId]);
    } else {
      setSelectedLeagues(selectedLeagues.filter(id => id !== leagueId));
    }
  };

  const navItems = [
    { icon: BarChart3, label: "Dashboard", active: true },
    { icon: Calendar, label: "Upcoming Matches", active: false },
    { icon: Trophy, label: "League Tables", active: false },
    { icon: Users, label: "Team Analytics", active: false },
    { icon: TrendingUp, label: "Predictions", active: false },
    { icon: History, label: "Historical Data", active: false },
  ];

  return (
    <aside className="fixed left-0 top-0 z-40 w-64 h-screen bg-sidebar border-r border-sidebar-border transition-transform -translate-x-full md:translate-x-0">
      <div className="p-4 md:p-6">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-sidebar-primary rounded-lg flex items-center justify-center">
            <Volleyball className="text-sidebar-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-sidebar-foreground" data-testid="logo-title">Sabiscore</h1>
            <p className="text-xs text-muted-foreground">Football Analytics</p>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  item.active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <Separator className="my-6" />

        {/* League Filter */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold text-sidebar-foreground">Leagues</h3>
            <Tooltip>
              <TooltipTrigger asChild>
                <div>
                  <Badge variant="outline" className="text-xs">
                    {selectedLeagues.length} selected
                  </Badge>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Filter matches by league</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <div className="space-y-3">
            {leagues.map((league) => (
              <Tooltip key={league.id}>
                <TooltipTrigger asChild>
                  <div className="flex items-center space-x-2 p-2 rounded-md hover:bg-sidebar-accent/50 transition-colors">
                    <Checkbox
                      id={league.id}
                      checked={selectedLeagues.includes(league.id)}
                      onCheckedChange={(checked) => handleLeagueToggle(league.id, checked as boolean)}
                      data-testid={`checkbox-${league.code.toLowerCase()}`}
                    />
                    <span className="text-base">{getLeagueFlag(league.country)}</span>
                    <label
                      htmlFor={league.id}
                      className="text-sm text-sidebar-foreground cursor-pointer flex items-center gap-2 flex-1"
                    >
                      <span className="font-medium">{league.code}</span>
                      {league.active && (
                        <Badge variant="secondary" className="text-xs bg-success/20 text-success border-success/30">
                          Live
                        </Badge>
                      )}
                    </label>
                  </div>
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p className="font-semibold">{league.name}</p>
                  <p className="text-xs text-muted-foreground">{league.country} • {league.active ? 'Active season' : 'Inactive'}</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}
