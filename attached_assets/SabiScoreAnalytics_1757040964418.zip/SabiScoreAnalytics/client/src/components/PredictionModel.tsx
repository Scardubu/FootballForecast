import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export default function PredictionModel() {
  const modelStats = {
    accuracy: 78.4,
    profitMargin: 15.7
  };

  const dataSources = [
    { name: "Live Match Stats", status: "Active", color: "success" },
    { name: "Historical Data", status: "Active", color: "success" },
    { name: "Player Form", status: "Active", color: "success" },
    { name: "Weather Data", status: "Updating", color: "secondary" }
  ];

  const getStatusColor = (color: string) => {
    switch (color) {
      case 'success': return 'bg-success text-success-foreground';
      case 'secondary': return 'bg-secondary text-secondary-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Prediction Model</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Model Performance */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-muted-foreground">Model Accuracy</span>
            <span className="font-medium text-success" data-testid="model-accuracy">
              {modelStats.accuracy}%
            </span>
          </div>
          <Progress value={modelStats.accuracy} className="h-2 [&>div]:bg-success" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-muted-foreground">Profit Margin</span>
            <span className="font-medium text-success" data-testid="profit-margin">
              +{modelStats.profitMargin}%
            </span>
          </div>
          <Progress value={65} className="h-2 [&>div]:bg-secondary" />
        </div>

        {/* Data Sources */}
        <div className="pt-4 border-t border-border">
          <h4 className="font-medium text-foreground mb-3">Data Sources</h4>
          <div className="space-y-2 text-sm">
            {dataSources.map((source, index) => (
              <div key={index} className="flex items-center gap-2" data-testid={`data-source-${source.name.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className={`w-2 h-2 rounded-full ${source.color === 'success' ? 'bg-success' : 'bg-secondary'}`}></div>
                <span className="text-muted-foreground flex-1">{source.name}</span>
                <Badge className={getStatusColor(source.color)} data-testid={`status-${source.name.toLowerCase().replace(/\s+/g, '-')}`}>
                  {source.status}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
