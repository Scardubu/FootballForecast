import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { Team, TeamStats, HeadToHead } from "@shared/schema";

export default function TeamComparison() {
  const [team1Id, setTeam1Id] = useState("team-3"); // Chelsea  
  const [team2Id, setTeam2Id] = useState("team-2"); // Arsenal

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: team1Stats } = useQuery<TeamStats>({
    queryKey: ["/api/teams", team1Id, "stats"],
    enabled: !!team1Id,
  });

  const { data: team2Stats } = useQuery<TeamStats>({
    queryKey: ["/api/teams", team2Id, "stats"],
    enabled: !!team2Id,
  });

  const { data: headToHead } = useQuery<HeadToHead>({
    queryKey: ["/api/teams", team1Id, "head-to-head", team2Id],
    enabled: !!team1Id && !!team2Id,
  });

  const team1 = teams.find(t => t.id === team1Id);
  const team2 = teams.find(t => t.id === team2Id);

  const renderFormBadges = (form: string | null) => {
    if (!form) return null;
    return form.split('').map((result, index) => {
      const bgColor = result === 'W' ? 'bg-success text-success-foreground' : 
                     result === 'D' ? 'bg-accent text-accent-foreground' : 
                     'bg-destructive text-destructive-foreground';
      return (
        <Badge key={index} className={`w-6 h-6 text-xs flex items-center justify-center ${bgColor}`}>
          {result}
        </Badge>
      );
    });
  };

  const getStatPercentage = (value: string | null | undefined) => {
    if (!value) return 0;
    const num = parseFloat(value);
    return Math.min(num * 10, 100); // Scale for display
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Team Comparison</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Team Selection */}
        <div className="grid grid-cols-2 gap-4">
          <Select value={team1Id} onValueChange={setTeam1Id}>
            <SelectTrigger data-testid="select-team1">
              <SelectValue placeholder="Select Team 1" />
            </SelectTrigger>
            <SelectContent>
              {teams.map((team) => (
                <SelectItem key={team.id} value={team.id}>
                  {team.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={team2Id} onValueChange={setTeam2Id}>
            <SelectTrigger data-testid="select-team2">
              <SelectValue placeholder="Select Team 2" />
            </SelectTrigger>
            <SelectContent>
              {teams.map((team) => (
                <SelectItem key={team.id} value={team.id}>
                  {team.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Comparison Metrics */}
        <div className="space-y-4">
          {/* Attack Rating */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Attack Rating</span>
              <span className="font-medium text-foreground" data-testid="attack-rating-comparison">
                {team1Stats?.attackRating || 'N/A'} vs {team2Stats?.attackRating || 'N/A'}
              </span>
            </div>
            <div className="flex gap-1">
              <div className="flex-1 bg-primary/20 rounded-full h-2">
                <Progress 
                  value={getStatPercentage(team1Stats?.attackRating)} 
                  className="h-2 [&>div]:bg-primary"
                />
              </div>
              <div className="flex-1 bg-secondary/20 rounded-full h-2">
                <Progress 
                  value={getStatPercentage(team2Stats?.attackRating)} 
                  className="h-2 [&>div]:bg-secondary"
                />
              </div>
            </div>
          </div>

          {/* Defense Rating */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Defense Rating</span>
              <span className="font-medium text-foreground" data-testid="defense-rating-comparison">
                {team1Stats?.defenseRating || 'N/A'} vs {team2Stats?.defenseRating || 'N/A'}
              </span>
            </div>
            <div className="flex gap-1">
              <div className="flex-1 bg-primary/20 rounded-full h-2">
                <Progress 
                  value={getStatPercentage(team1Stats?.defenseRating)} 
                  className="h-2 [&>div]:bg-primary"
                />
              </div>
              <div className="flex-1 bg-secondary/20 rounded-full h-2">
                <Progress 
                  value={getStatPercentage(team2Stats?.defenseRating)} 
                  className="h-2 [&>div]:bg-secondary"
                />
              </div>
            </div>
          </div>

          {/* Recent Form */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Recent Form (5 matches)</span>
              <span className="font-medium text-foreground" data-testid="form-comparison">
                {team1?.form || 'N/A'} vs {team2?.form || 'N/A'}
              </span>
            </div>
            <div className="flex justify-between">
              <div className="flex gap-1">
                {renderFormBadges(team1?.form || null)}
              </div>
              <div className="flex gap-1">
                {renderFormBadges(team2?.form || null)}
              </div>
            </div>
          </div>

          {/* Head to Head */}
          {headToHead && (
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Head-to-Head (Last {headToHead.totalMatches})</span>
                <span className="font-medium text-foreground" data-testid="h2h-record">
                  {headToHead.team1Wins}W {headToHead.draws}D {headToHead.team2Wins}L
                </span>
              </div>
              <div className="flex gap-2 text-xs">
                <Badge className="bg-primary/20 text-primary">
                  {team1?.shortName}: {headToHead.team1Wins} wins
                </Badge>
                <Badge className="bg-muted text-muted-foreground">
                  Draws: {headToHead.draws}
                </Badge>
                <Badge className="bg-secondary/20 text-secondary">
                  {team2?.shortName}: {headToHead.team2Wins} wins
                </Badge>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
