import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Flame, Clock, Activity, Zap } from "lucide-react";

export default function TrendingInsights() {
  const insights = [
    {
      icon: TrendingUp,
      title: "High-Scoring Trend",
      description: "Premier League matches averaging 3.2 goals this week",
      bgColor: "bg-success/10",
      iconColor: "text-success",
      badge: "This Week",
      badgeColor: "bg-success/20 text-success",
      tooltip: "Goals per match have increased by 15% compared to last week. Over 2.5 goals markets showing strong value."
    },
    {
      icon: Flame,
      title: "Away Form Surge", 
      description: "Away teams winning 45% of matches this season",
      bgColor: "bg-secondary/10",
      iconColor: "text-secondary",
      badge: "Season Trend",
      badgeColor: "bg-secondary/20 text-secondary",
      tooltip: "Historical average is 35%. This presents opportunities in away win and draw no bet markets."
    },
    {
      icon: Clock,
      title: "Late Goals Pattern",
      description: "65% of goals scored after 60th minute",
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      badge: "Live Betting",
      badgeColor: "bg-primary/20 text-primary",
      tooltip: "Consider in-play betting strategies. Most goals happen in final 30 minutes across all leagues."
    },
    {
      icon: Activity,
      title: "VAR Impact",
      description: "12% more penalties awarded with VAR implementation",
      bgColor: "bg-accent/10",
      iconColor: "text-accent",
      badge: "New Data",
      badgeColor: "bg-accent/20 text-accent",
      tooltip: "Penalty markets showing increased activity. Consider total bookings and penalty Yes/No bets."
    }
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-secondary" />
          <CardTitle>Trending Insights</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <Tooltip key={index}>
              <TooltipTrigger asChild>
                <div 
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors cursor-pointer border border-transparent hover:border-border"
                  data-testid={`insight-${insight.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className={`w-10 h-10 ${insight.bgColor} rounded-lg flex items-center justify-center flex-shrink-0 shadow-sm`}>
                    <Icon className={`${insight.iconColor} w-5 h-5`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-foreground text-sm">{insight.title}</p>
                      <Badge className={`text-xs ${insight.badgeColor} border-0`}>
                        {insight.badge}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{insight.description}</p>
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="font-semibold mb-1">{insight.title}</p>
                <p className="text-xs">{insight.tooltip}</p>
              </TooltipContent>
            </Tooltip>
          );
        })}
      </CardContent>
    </Card>
  );
}
