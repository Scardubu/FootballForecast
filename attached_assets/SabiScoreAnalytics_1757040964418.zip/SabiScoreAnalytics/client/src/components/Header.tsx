import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { RefreshCw, User } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [syncing, setSyncing] = useState(false);

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 2000);
  };

  return (
    <header className="bg-card border-b border-border px-8 py-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground" data-testid="header-title">
            Football Analytics Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Generate insights and predictions for upcoming matches
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Button 
            onClick={handleSync}
            disabled={syncing}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            data-testid="button-sync-data"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync Data'}
          </Button>
          <Avatar data-testid="avatar-user">
            <AvatarFallback className="bg-muted">
              <User className="w-5 h-5 text-muted-foreground" />
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
