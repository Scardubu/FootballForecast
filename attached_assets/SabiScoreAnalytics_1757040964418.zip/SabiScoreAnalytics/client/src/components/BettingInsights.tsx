import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { TrendingUp, AlertTriangle, Zap, Target, Sparkles, Info, DollarSign, BarChart3 } from "lucide-react";
import type { Prediction } from "@shared/schema";

export default function BettingInsights() {
  const { data: predictions = [] } = useQuery<Prediction[]>({
    queryKey: ["/api/predictions"],
  });

  const sortedPredictions = predictions.sort((a, b) => parseFloat(b.confidence) - parseFloat(a.confidence));
  const topPrediction = sortedPredictions[0];
  const highValuePredictions = sortedPredictions.filter(p => parseFloat(p.expectedValue || "0") > 10).slice(0, 3);
  const otherPredictions = sortedPredictions.filter(p => p.id !== topPrediction?.id).slice(0, 3);

  const getConfidenceColor = (confidence: string) => {
    const conf = parseFloat(confidence);
    if (conf >= 85) return "bg-gradient-to-r from-success to-success/90 text-success-foreground shadow-lg";
    if (conf >= 75) return "bg-gradient-to-r from-secondary to-secondary/90 text-secondary-foreground shadow-md";
    if (conf >= 65) return "bg-gradient-to-r from-primary to-primary/90 text-primary-foreground";
    return "bg-gradient-to-r from-muted to-muted/90 text-muted-foreground";
  };

  const getValueRating = (expectedValue: string) => {
    const ev = parseFloat(expectedValue || "0");
    if (ev >= 15) return { label: "Excellent", color: "text-success", icon: Sparkles };
    if (ev >= 10) return { label: "Good", color: "text-secondary", icon: TrendingUp };
    if (ev >= 5) return { label: "Fair", color: "text-primary", icon: Target };
    return { label: "Low", color: "text-muted-foreground", icon: AlertTriangle };
  };

  const getPredictionTypeLabel = (type: string) => {
    switch (type) {
      case "over_under": return "Over/Under";
      case "btts": return "Both Teams to Score";
      case "match_result": return "Match Result";
      default: return type;
    }
  };

  const getPredictionLabel = (prediction: string) => {
    switch (prediction) {
      case "over_2.5": return "Over 2.5 Goals";
      case "btts_yes": return "BTTS - Yes";
      case "home": return "Home Win";
      case "away": return "Away Win";
      default: return prediction;
    }
  };

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-secondary" />
            <CardTitle>AI Betting Insights</CardTitle>
          </div>
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="outline" className="gap-1">
                <BarChart3 className="w-3 h-3" />
                Live Analysis
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Real-time predictions powered by our AI model</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Premium Featured Prediction */}
        {topPrediction && (
          <div className="relative bg-gradient-to-br from-primary/8 via-secondary/6 to-success/8 rounded-xl p-6 border-2 border-primary/20 backdrop-blur-sm" data-testid="featured-prediction">
            <div className="absolute top-3 right-3">
              <Badge className="bg-gradient-to-r from-secondary to-secondary/90 text-secondary-foreground">
                <Sparkles className="w-3 h-3 mr-1" />
                Premium Pick
              </Badge>
            </div>
            
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="font-bold text-foreground text-xl mb-1" data-testid="featured-prediction-title">
                  {getPredictionLabel(topPrediction.prediction)}
                </h3>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Target className="w-3 h-3" />
                  {getPredictionTypeLabel(topPrediction.predictionType)}
                </p>
              </div>
            </div>
            
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Confidence Level</span>
                <span className="text-sm font-bold">{parseFloat(topPrediction.confidence).toFixed(1)}%</span>
              </div>
              <Progress value={parseFloat(topPrediction.confidence)} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-success [&>div]:to-success/80" />
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center p-3 bg-card/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Odds</p>
                <p className="font-bold text-primary text-lg">{topPrediction.odds}</p>
              </div>
              <div className="text-center p-3 bg-card/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Expected Value</p>
                <p className="font-bold text-success text-lg">+{topPrediction.expectedValue}%</p>
              </div>
              <div className="text-center p-3 bg-card/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Kelly %</p>
                <p className="font-bold text-secondary text-lg">8.5%</p>
              </div>
            </div>
            
            <div className="bg-card/30 rounded-lg p-3 mb-4">
              <p className="text-xs text-muted-foreground mb-1">AI Analysis</p>
              <p className="text-sm">{topPrediction.reasoning}</p>
            </div>
            
            <Button className="w-full bg-gradient-to-r from-primary to-primary/90" size="lg">
              <DollarSign className="w-4 h-4 mr-2" />
              Place Bet
            </Button>
          </div>
        )}

        {/* High-Value Predictions */}
        {highValuePredictions.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-secondary" />
              <h4 className="font-semibold text-foreground">High-Value Bets</h4>
            </div>
            <div className="grid gap-3">
              {highValuePredictions.map((prediction) => {
                const valueRating = getValueRating(prediction.expectedValue || "0");
                const ValueIcon = valueRating.icon;
                return (
                  <Tooltip key={prediction.id}>
                    <TooltipTrigger asChild>
                      <div
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-muted/30 to-muted/10 rounded-lg border hover:border-primary/30 transition-all cursor-pointer"
                        data-testid={`prediction-${prediction.id}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${valueRating.color === 'text-success' ? 'bg-success/20' : valueRating.color === 'text-secondary' ? 'bg-secondary/20' : 'bg-primary/20'}`}>
                            <ValueIcon className={`w-4 h-4 ${valueRating.color}`} />
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{getPredictionLabel(prediction.prediction)}</p>
                            <p className="text-sm text-muted-foreground">{getPredictionTypeLabel(prediction.predictionType)}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <Badge className={getConfidenceColor(prediction.confidence)}>
                              {parseFloat(prediction.confidence).toFixed(0)}%
                            </Badge>
                            <Badge variant="outline" className={`${valueRating.color} border-current`}>
                              +{prediction.expectedValue}%
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">Odds: {prediction.odds}</p>
                        </div>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p className="font-semibold mb-1">{valueRating.label} Value Bet</p>
                      <p className="text-xs">{prediction.reasoning}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Other Predictions */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-muted-foreground" />
            <h4 className="font-semibold text-foreground">More Predictions</h4>
          </div>
          <div className="space-y-2">
            {otherPredictions.map((prediction) => (
              <div
                key={prediction.id}
                className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                data-testid={`prediction-${prediction.id}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${parseFloat(prediction.confidence) >= 75 ? 'bg-success/20' : 'bg-secondary/20'}`}>
                    {parseFloat(prediction.confidence) >= 75 ? (
                      <TrendingUp className="text-success w-3 h-3" />
                    ) : (
                      <Target className="text-secondary w-3 h-3" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">{getPredictionLabel(prediction.prediction)}</p>
                    <p className="text-xs text-muted-foreground">{getPredictionTypeLabel(prediction.predictionType)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-bold text-sm ${parseFloat(prediction.confidence) >= 75 ? 'text-success' : 'text-secondary'}`}>
                    {parseFloat(prediction.confidence).toFixed(0)}%
                  </p>
                  <p className="text-xs text-muted-foreground">Odds: {prediction.odds}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
