import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, PieChart } from "lucide-react";

export default function AnalyticsCharts() {
  const tabs = [
    { label: "Overview", active: true },
    { label: "Stats", active: false },
    { label: "H2H", active: false },
    { label: "Form", active: false }
  ];

  return (
    <div className="space-y-8">
      {/* Performance Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Prediction Accuracy Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Prediction Accuracy Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 relative bg-muted/30 rounded-lg flex items-center justify-center">
              {/* Chart Placeholder */}
              <div className="absolute inset-4">
                {/* Mock chart visualization */}
                <svg width="100%" height="100%" className="absolute inset-0">
                  <polyline 
                    points="20,180 80,120 140,100 200,80 260,90 320,60" 
                    fill="none" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth="3" 
                    strokeLinecap="round"
                  />
                  <circle cx="320" cy="60" r="4" fill="hsl(var(--primary))" />
                </svg>
                {/* Y-axis labels */}
                <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-muted-foreground py-2">
                  <span>100%</span>
                  <span>80%</span>
                  <span>60%</span>
                  <span>40%</span>
                  <span>20%</span>
                </div>
                {/* X-axis labels */}
                <div className="absolute bottom-0 left-6 right-0 flex justify-between text-xs text-muted-foreground">
                  <span>Jan</span>
                  <span>Feb</span>
                  <span>Mar</span>
                  <span>Apr</span>
                  <span>May</span>
                  <span>Jun</span>
                </div>
              </div>
              <div className="text-center z-10">
                <BarChart3 className="w-16 h-16 text-muted-foreground mb-2 mx-auto" />
                <p className="text-muted-foreground">Interactive Chart</p>
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-muted-foreground">
                Current accuracy: <span className="font-bold text-success" data-testid="current-accuracy">78.4%</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Value Bet Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Value Bet Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 relative bg-muted/30 rounded-lg flex items-center justify-center">
              <div className="relative w-40 h-40">
                {/* Mock donut chart */}
                <svg width="160" height="160" className="absolute inset-0">
                  <circle cx="80" cy="80" r="60" fill="none" stroke="hsl(var(--muted))" strokeWidth="20"/>
                  <circle 
                    cx="80" cy="80" r="60" fill="none" stroke="hsl(var(--success))" strokeWidth="20"
                    strokeDasharray="150 377" strokeDashoffset="0" transform="rotate(-90 80 80)"
                  />
                  <circle 
                    cx="80" cy="80" r="60" fill="none" stroke="hsl(var(--secondary))" strokeWidth="20"
                    strokeDasharray="100 377" strokeDashoffset="-150" transform="rotate(-90 80 80)"
                  />
                  <circle 
                    cx="80" cy="80" r="60" fill="none" stroke="hsl(var(--primary))" strokeWidth="20"
                    strokeDasharray="127 377" strokeDashoffset="-250" transform="rotate(-90 80 80)"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-foreground" data-testid="total-value-bets">324</p>
                    <p className="text-xs text-muted-foreground">Value Bets</p>
                  </div>
                </div>
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex justify-center gap-4 text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <span className="text-muted-foreground">High Value</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-secondary rounded-full"></div>
                    <span className="text-muted-foreground">Medium Value</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Low Value</span>
                  </div>
                </div>
              </div>
              <div className="text-center z-10 absolute inset-0 flex items-center justify-center opacity-20">
                <PieChart className="w-16 h-16 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Match Analysis */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Match Deep Dive: Chelsea vs Arsenal</CardTitle>
            <div className="flex gap-2">
              {tabs.map((tab, index) => (
                <Button
                  key={index}
                  variant={tab.active ? "default" : "ghost"}
                  size="sm"
                  className={tab.active ? "bg-primary text-primary-foreground" : ""}
                  data-testid={`tab-${tab.label.toLowerCase()}`}
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Match Prediction */}
            <div className="bg-gradient-to-br from-primary/5 to-secondary/5 rounded-lg p-6 border border-primary/20">
              <h3 className="font-semibold text-foreground mb-4">Match Outcome Prediction</h3>
              <div className="space-y-3">
                {[
                  { team: "Chelsea Win", percentage: 35, color: "primary" },
                  { team: "Draw", percentage: 28, color: "accent" },
                  { team: "Arsenal Win", percentage: 37, color: "secondary" }
                ].map((prediction) => (
                  <div key={prediction.team} className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{prediction.team}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            prediction.color === 'primary' ? 'bg-primary' :
                            prediction.color === 'secondary' ? 'bg-secondary' : 'bg-accent'
                          }`}
                          style={{ width: `${prediction.percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-foreground" data-testid={`prediction-${prediction.team.toLowerCase().replace(/\s+/g, '-')}`}>
                        {prediction.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-card/50 rounded-lg">
                <p className="text-xs text-muted-foreground">Recommended Bet</p>
                <p className="font-bold text-secondary">Arsenal Win or Draw</p>
                <p className="text-xs text-muted-foreground">Expected Value: +8.2%</p>
              </div>
            </div>

            {/* Key Stats */}
            <div className="bg-muted/30 rounded-lg p-6">
              <h3 className="font-semibold text-foreground mb-4">Key Statistics</h3>
              <div className="space-y-4">
                {[
                  { stat: "Goals per Match", values: "1.8 vs 2.1", team1: 60, team2: 70 },
                  { stat: "Shots on Target", values: "4.2 vs 5.1", team1: 55, team2: 67 },
                  { stat: "Clean Sheets", values: "45% vs 38%", team1: 45, team2: 38 },
                  { stat: "Possession %", values: "58% vs 62%", team1: 58, team2: 62 }
                ].map((stat) => (
                  <div key={stat.stat}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">{stat.stat}</span>
                      <span className="font-medium text-foreground" data-testid={`stat-${stat.stat.toLowerCase().replace(/\s+/g, '-')}`}>
                        {stat.values}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <div className="flex-1 bg-muted rounded-full h-1.5">
                        <div className="bg-primary h-1.5 rounded-full" style={{ width: `${stat.team1}%` }}></div>
                      </div>
                      <div className="flex-1 bg-muted rounded-full h-1.5">
                        <div className="bg-secondary h-1.5 rounded-full" style={{ width: `${stat.team2}%` }}></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Betting Markets */}
            <div className="bg-muted/30 rounded-lg p-6">
              <h3 className="font-semibold text-foreground mb-4">Value Betting Markets</h3>
              <div className="space-y-3">
                {[
                  { market: "Over 2.5 Goals", description: "Both teams avg 2+ goals", rating: "Value", color: "success", odds: "1.85" },
                  { market: "Arsenal +0.5 AH", description: "Strong away form", rating: "Good", color: "secondary", odds: "1.92" },
                  { market: "1st Half Draw", description: "Cautious start expected", rating: "Fair", color: "primary", odds: "2.10" }
                ].map((market) => (
                  <div key={market.market} className="flex items-center justify-between p-3 bg-card rounded border border-border">
                    <div>
                      <p className="font-medium text-foreground text-sm">{market.market}</p>
                      <p className="text-xs text-muted-foreground">{market.description}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${
                        market.color === 'success' ? 'text-success' :
                        market.color === 'secondary' ? 'text-secondary' : 'text-primary'
                      }`} data-testid={`rating-${market.market.toLowerCase().replace(/\s+/g, '-')}`}>
                        {market.rating}
                      </p>
                      <p className="text-xs text-muted-foreground">{market.odds} odds</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
