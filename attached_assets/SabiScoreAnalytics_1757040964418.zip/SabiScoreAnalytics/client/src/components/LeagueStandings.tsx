import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ExternalLink } from "lucide-react";
import type { Team, League } from "@shared/schema";

export default function LeagueStandings() {
  const [selectedLeagueId, setSelectedLeagueId] = useState("pl-1");

  const { data: leagues = [] } = useQuery<League[]>({
    queryKey: ["/api/leagues"],
  });

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/leagues", selectedLeagueId, "teams"],
    enabled: !!selectedLeagueId,
  });

  const selectedLeague = leagues.find(l => l.id === selectedLeagueId);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <CardTitle data-testid="league-standings-title">
              {selectedLeague?.name || "League Standings"}
            </CardTitle>
            <Select value={selectedLeagueId} onValueChange={setSelectedLeagueId}>
              <SelectTrigger className="w-32" data-testid="select-league">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {leagues.map((league) => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.code}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <ExternalLink className="w-4 h-4 text-muted-foreground cursor-pointer hover:text-primary" />
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">#</TableHead>
              <TableHead>Team</TableHead>
              <TableHead className="text-center w-12">P</TableHead>
              <TableHead className="text-center w-16">Pts</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {teams.map((team) => (
              <TableRow 
                key={team.id} 
                className="hover:bg-muted/50"
                data-testid={`table-row-${team.shortName.toLowerCase()}`}
              >
                <TableCell className="font-medium" data-testid={`position-${team.shortName.toLowerCase()}`}>
                  {team.position}
                </TableCell>
                <TableCell className="font-medium" data-testid={`team-name-${team.shortName.toLowerCase()}`}>
                  {team.name}
                </TableCell>
                <TableCell className="text-center" data-testid={`played-${team.shortName.toLowerCase()}`}>
                  {team.played}
                </TableCell>
                <TableCell className="text-center font-bold" data-testid={`points-${team.shortName.toLowerCase()}`}>
                  {team.points}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
