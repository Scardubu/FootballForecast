export interface DashboardStats {
  todayMatches: number;
  predictionAccuracy: number;
  activeLeagues: number;
  totalPredictions: number;
}

export interface EnrichedMatch {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  leagueId: string;
  kickoffTime: string | Date;
  status: "scheduled" | "live" | "finished";
  homeScore: number | null;
  awayScore: number | null;
  odds: {
    home: number;
    draw: number;
    away: number;
  } | null;
  homeTeam: {
    id: string;
    name: string;
    shortName: string;
    form?: string;
  };
  awayTeam: {
    id: string;
    name: string;
    shortName: string;
    form?: string;
  };
  league: {
    id: string;
    name: string;
    code: string;
  };
}

export interface PredictionInsight {
  id: string;
  matchId: string;
  predictionType: string;
  prediction: string;
  confidence: number;
  odds: number;
  expectedValue: number;
  reasoning?: string;
}

export interface TeamComparisonData {
  team1: {
    id: string;
    name: string;
    shortName: string;
    stats: {
      attackRating: number;
      defenseRating: number;
      goalsPerMatch: number;
      shotsOnTarget: number;
      cleanSheetPercentage: number;
      possessionPercentage: number;
    };
    form: string;
  };
  team2: {
    id: string;
    name: string;
    shortName: string;
    stats: {
      attackRating: number;
      defenseRating: number;
      goalsPerMatch: number;
      shotsOnTarget: number;
      cleanSheetPercentage: number;
      possessionPercentage: number;
    };
    form: string;
  };
  headToHead: {
    team1Wins: number;
    team2Wins: number;
    draws: number;
    totalMatches: number;
  };
}
