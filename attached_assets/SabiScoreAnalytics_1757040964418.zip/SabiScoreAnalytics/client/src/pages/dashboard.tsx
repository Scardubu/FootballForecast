import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatsOverview from "@/components/StatsOverview";
import MatchSelection from "@/components/MatchSelection";
import BettingInsights from "@/components/BettingInsights";
import TeamComparison from "@/components/TeamComparison";
import LeagueStandings from "@/components/LeagueStandings";
import TrendingInsights from "@/components/TrendingInsights";
import PredictionModel from "@/components/PredictionModel";
import AnalyticsCharts from "@/components/AnalyticsCharts";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-0 md:ml-64 min-h-screen transition-all duration-300">
        <Header />
        
        <div className="p-4 md:p-6 lg:p-8">
          <StatsOverview />
          
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
            <div className="xl:col-span-2 space-y-4 md:space-y-6">
              <MatchSelection />
              <BettingInsights />
              <TeamComparison />
            </div>
            
            <div className="space-y-4 md:space-y-6">
              <PredictionModel />
              <LeagueStandings />
              <TrendingInsights />
            </div>
          </div>
          
          <div className="mt-6 md:mt-8">
            <AnalyticsCharts />
          </div>
        </div>
      </main>
    </div>
  );
}
